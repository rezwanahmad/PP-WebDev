# Approved Contact Patch — Controlled Maintenance Runbook

**Prepared:** 24 August 2026  
**Approved displayed contact:** `92315-500-9620`  
**Technical WhatsApp URL:** `https://wa.me/923155009620`  
**Public email:** `info@pathplaza.com` as plain text plus `mailto:`

## Scope

- Removes the internal-only UK contact from shared `header.html` and `footer.html`.
- Replaces obsolete displayed Pakistan-number formats with `92315-500-9620`.
- Preserves digits-only WhatsApp links and E.164 schema values.
- Replaces Cloudflare-obfuscated email output in the privacy page with plain text email.
- Includes the current blog index and article files so contact formatting stays consistent.

## Controlled maintenance procedure

1. Announce a 10–15 minute maintenance window; pause concurrent file uploads.
2. Download backups of every file in this bundle from production.
3. Upload `header.html` and `footer.html` first.
4. Upload the remaining root HTML files.
5. Upload all included `blog/*.html` files.
6. Upload the font only if it is not already present.
7. Do not upload `_article-template.html`.
8. Purge LiteSpeed/Hostinger page cache.
9. Purge Cloudflare custom URLs for `header.html`, `footer.html`, the homepage, core pages, blog index and article URLs. Use “Purge Everything” only if custom purge is unavailable and management accepts the wider impact.
10. Open production in a private/incognito window and complete the checks below.

## Cache-purge URL set

- `https://pathplaza.com/header.html`
- `https://pathplaza.com/footer.html`
- `https://pathplaza.com/`
- `https://pathplaza.com/index.html`
- `https://pathplaza.com/about.html`
- `https://pathplaza.com/services.html`
- `https://pathplaza.com/universities.html`
- `https://pathplaza.com/initial-profile-review.html`
- `https://pathplaza.com/destinations.html`
- `https://pathplaza.com/blog.html`
- All URLs listed in the bundled `sitemap.xml`

## Production acceptance checks

- Homepage top bar shows `92315-500-9620` once and no UK contact.
- Footer shows `92315-500-9620` once and no UK contact.
- Clicking WhatsApp opens `wa.me/923155009620`.
- `info@pathplaza.com` is visible and links to `mailto:info@pathplaza.com`.
- Search fetched HTML for `+44`, `7577`, `447577`, `+92 315 5009620`, `+92 3155009620`, and `+92 315 500-9620`; all must return zero.
- Core pages, blog index and article URLs return HTTP 200.
- No article URL returns sitemap or template content.

## Command-line verification

```bash
curl -fsSL https://pathplaza.com/header.html | grep -E '+44|7577|447577|\+92 315 5009620|\+92 3155009620|\+92 315 500-9620'
curl -fsSL https://pathplaza.com/footer.html | grep -E '+44|7577|447577|\+92 315 5009620|\+92 3155009620|\+92 315 500-9620'
curl -fsSL https://pathplaza.com/header.html | grep -F '92315-500-9620'
```

The first two commands must return no matches. The third must return the approved display.

## Rollback

If navigation, contact links or page rendering fail, restore the downloaded backups immediately, purge the same cache URLs again, and log the failure before retrying.

## Authority boundary

PP-WEBDEV prepared and verified this deployment bundle. A human with approved hosting/CDN access must upload the files and execute cache purges; credentials must not be shared in chat or embedded in files.
