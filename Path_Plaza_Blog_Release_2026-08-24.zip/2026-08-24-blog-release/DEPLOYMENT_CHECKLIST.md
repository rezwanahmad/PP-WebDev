# Path Plaza Blog Release Bundle — 24 August 2026

## Why this bundle exists

A blog post must never be uploaded by itself. The article, `blog.html`, `sitemap.xml`, language assets and cross-links are one release unit.

The live check before this bundle found:

- the Urdu visa URL serving an article-template placeholder;
- the Urdu fees URL returning 404;
- the English fee URL returning incorrect sitemap-like content;
- the blog index showing only two main cards instead of every published language page.

This bundle supplies corrected files together.

## Upload order

1. Upload `fonts/NotoNastaliqUrdu-Arabic.woff2`.
2. Retain `fonts/NotoNastaliqUrdu-OFL.txt` in the deployment/archive package.
3. Upload all four files in `blog/` that end in `.html`.
4. Upload root `blog.html`.
5. Upload root `sitemap.xml`.
6. Purge LiteSpeed and CDN caches.
7. Do not upload any `_article-template.html` file.

## Required production URLs

- `/blog/turkey-student-visa-documents-pakistan.html`
- `/blog/turkey-student-visa-documents-pakistan-urdu.html`
- `/blog/turkey-university-fees-pakistani-students-2026.html`
- `/blog/turkey-university-fees-pakistani-students-2026-urdu.html`
- `/blog.html`
- `/sitemap.xml`

## Acceptance checks

- Every article URL returns HTTP 200 and its own article title.
- No article URL returns sitemap content or template tokens.
- `blog.html` shows four article cards: two English and two Urdu.
- The Urdu filter shows two cards.
- All filter counts are correct after JavaScript loads.
- English–Urdu language switches work in both directions.
- Nastaleeq font loads on both Urdu articles.
- Blog JSON-LD lists four posts with correct `inLanguage` values.
- Sitemap lists each article once and includes reciprocal `en-PK`, `ur-PK`, and `x-default` links.
- Modified dates and sitemap `lastmod` use 24 August 2026.
- No `ARTICLE TITLE`, `{{TOKEN}}`, internal-only contact or prohibited claim appears in release files.
- Submit the sitemap in Search Console only after all checks pass.

## Future standing rule

Every new article delivery must include, in the same turn:

1. Article HTML
2. Updated `blog.html`
3. Updated `sitemap.xml`
4. Required assets
5. Deployment/QA guide
6. One release bundle

The article is not complete until all six items agree.
