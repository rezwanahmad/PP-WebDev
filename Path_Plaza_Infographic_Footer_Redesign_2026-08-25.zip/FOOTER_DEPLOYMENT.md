# Path Plaza All-Device Infographic Footer — Deployment Notes

**Date:** 25 August 2026  
**File:** `footer.html`  
**Status:** Rebuilt and QA-checked; not uploaded in this session.

## Rebuild summary

The footer was rebuilt around a fluid layout rather than additional one-off breakpoint patches.

- Full-width brand band with logo, description and four proof cards.
- Four matching panels: Explore, Destination routes, Support and Contact.
- Four-step student journey infographic.
- Four active destination routes.
- Fluid spacing and typography using `clamp()`.
- Container-aware component with a 1280px maximum content width.
- Overflow protection for long labels, email and policy links.
- Touch-friendly controls and social buttons.
- Safe-area support for modern phones.
- No external stylesheet, Font Awesome, CDN or component JavaScript.

## Device behaviour

- **Ultrawide and desktop:** four equal section panels; four-step journey.
- **Laptop and tablet:** two section columns; two-row journey; two-column proof cards.
- **Portrait tablet and large phone:** stacked CTA and flexible brand band.
- **Standard phone:** one section panel per row; compact destination grid.
- **Small phone, including 320–340px:** vertical journey, one-column proof cards and reduced padding.
- **Landscape phone:** reduced vertical padding.
- **Print:** simplified light layout.
- **Reduced motion:** transitions effectively disabled.

## Contact requirements

- Visible number: `92315-500-9620`
- WhatsApp target: `https://wa.me/923155009620`
- Plain email: `info@pathplaza.com`
- Email link: `mailto:info@pathplaza.com`
- No protection, encoding or obfuscation code

## Deployment

1. Back up production `footer.html`.
2. Upload the new root-level `footer.html`.
3. Keep `/images/Logo.png` available.
4. Purge `footer.html` and representative page caches.
5. Test at approximately 1440, 1024, 768, 430, 375 and 320 CSS pixels.
6. Test at least one landscape-phone viewport.
7. Verify the 4→2→1 journey and panel transitions.
8. Verify the CTA, country links, contact links and social buttons.
9. Confirm the plain email was not rewritten by Cloudflare.
10. Run the production crawl smoke test.

## Email-protection requirement

Cloudflare Email Address Obfuscation must remain disabled. The source file contains a plain email and no protection code, but Cloudflare can rewrite it after deployment if the zone feature is enabled.

## Integration

The component remains a shared HTML fragment that can be injected from the same origin:

```html
<div id="site-footer"></div>
<script>
fetch('footer.html')
  .then(response => response.text())
  .then(html => { document.getElementById('site-footer').innerHTML = html; });
</script>
```

## Rollback

Restore the backed-up `footer.html`, purge cache and retest representative devices.
