# Path Plaza Footer Redesign — Deployment Notes

**Date:** 25 August 2026  
**File:** `footer.html`  
**Status:** Built and QA-checked; not uploaded to production in this session.

## Change summary

- Rebuilt the shared footer as a responsive, professional Path Plaza component.
- Added a prominent Free Initial Profile Check call-to-action.
- Added structured Explore, Destinations and Support navigation.
- Added a dedicated office/contact card.
- Added approved Instagram, Facebook, X, LinkedIn and YouTube buttons.
- Replaced the external Font Awesome dependency with embedded SVG icons.
- Removed old commented-out navigation and malformed HTML.
- Kept visible contact exactly `92315-500-9620`.
- Kept WhatsApp target exactly `https://wa.me/923155009620`.
- Kept plain visible `info@pathplaza.com` with `mailto:info@pathplaza.com`.
- Added tablet, mobile, reduced-motion and print styles.

## Deployment

1. Back up the current production `footer.html`.
2. Upload the new `footer.html` to the site root.
3. Do not rename `/images/Logo.png`; the footer uses this existing approved asset.
4. Purge the cache for `footer.html` and pages that inject it.
5. Open home, destination, legal, profile-review and blog pages at desktop and mobile widths.
6. Confirm all internal links, CTA, WhatsApp, email and social buttons.
7. Confirm the displayed number remains `92315-500-9620`.
8. Confirm the email remains plain and clickable.

## Email protection requirement

The file contains plain `info@pathplaza.com` and no obfuscation code. Cloudflare Email Address Obfuscation must remain disabled; otherwise Cloudflare may rewrite the correct source after upload.

## Integration dependency

Pages that use the shared component should inject it from the same origin, for example:

```html
<div id="site-footer"></div>
<script>
fetch('footer.html')
  .then(response => response.text())
  .then(html => { document.getElementById('site-footer').innerHTML = html; });
</script>
```

The component has no JavaScript of its own and no external stylesheet dependency.

## Rollback

Restore the backed-up `footer.html`, purge cache, and verify the same representative pages again.
