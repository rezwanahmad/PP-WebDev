# QA Report — Study in Turkey from Pakistan Beginner Guide

**Run date:** 25 August 2026  
**Result:** **PASS for build package**  
**Production publication:** Not performed

## Content and source checks

- [x] Plain, simple English used throughout.
- [x] One clear H1.
- [x] Real publication and source-check date: 25 August 2026.
- [x] Nine official source links included and dated.
- [x] YÖK university count checked: 208.
- [x] Current direct-application and TR-YÖS wording used.
- [x] Degree durations match the official NQF-HETR ranges.
- [x] Bologna membership explained without promising automatic recognition.
- [x] Scholarship existence described as competitive; no award promise.
- [x] No tuition, PKR, USD or universal total-cost figures published.
- [x] No admission, visa, scholarship, employment or settlement guarantee.

## SEO and schema checks

- [x] Title length: 59 characters.
- [x] Meta description length: 145 characters.
- [x] Self-referencing canonical present.
- [x] `en-PK` and `x-default` self-alternates present.
- [x] Open Graph and large-image card metadata present.
- [x] BlogPosting JSON-LD parsed successfully.
- [x] BreadcrumbList JSON-LD parsed successfully.
- [x] FAQPage JSON-LD parsed successfully.
- [x] Seven visible FAQs match seven schema questions.
- [x] OG image is 1200 × 630 and 95,837 bytes.

## Release coordination checks

- [x] New article file created.
- [x] `blog.html` updated to 17 visible article cards.
- [x] Blog JSON-LD updated to 17 BlogPosting records.
- [x] New article is the featured article.
- [x] Filter categories updated: Turkey 17, Process 11, Family 3, Urdu unchanged at 8.
- [x] `sitemap.xml` updated to 17 article URLs.
- [x] New sitemap entry occurs once and has correct self-alternates.
- [x] Blog and sitemap modification date updated to 25 August 2026.

## Contact and template checks

- [x] Visible number uses exactly `92315-500-9620`.
- [x] WhatsApp targets use `https://wa.me/923155009620`.
- [x] No obsolete Pakistan contact format detected in the new article.
- [x] No internal UK number detected.
- [x] Plain `info@pathplaza.com` email and `mailto:` link present.
- [x] No template variables or placeholder tokens detected in the new article.
- [x] Pre-existing `{right_title}` token removed from both linked IELTS pages.
- [x] English and Urdu IELTS canonicals, Open Graph URLs, schema URLs and analytics slugs corrected to self.

## Technical and accessibility checks

- [x] Responsive breakpoints included for desktop, tablet and mobile.
- [x] Desktop and mobile contents navigation included.
- [x] Tables have captions and scrollable wrappers.
- [x] Infographics are followed by plain text or accessible tables where exact details matter.
- [x] Keyboard focus styles and skip link included.
- [x] Reduced-motion and print styles included.
- [x] Article file is 52,298 bytes, below the 1 MB limit.
- [x] JSON-LD and sitemap XML parse without errors.
- [x] Thirty-two internal and official-source URLs were requested during QA; all returned HTTP 200 or a successful redirect.

## Dependencies and unresolved items

- Production upload, cache purge and post-release crawl require human hosting/CDN access.
- `/images/Logo.png` is an existing production dependency and must remain available.
- `PP_GA4_ID` is intentionally blank until management approval.
- The article is English only, as requested. No Urdu publication date or counterpart was invented.
- The wider production contact-release smoke test remains failed for separate shell, country-page, canonical and broken-link issues. This package does not close that ticket.
- Final human management approval is required before public upload.
