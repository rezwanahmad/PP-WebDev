# Deployment Notes — Study in Turkey from Pakistan Beginner Guide

**Release date:** 25 August 2026  
**Language:** Plain English (`en-PK`)  
**Canonical URL:** `https://pathplaza.com/blog/study-in-turkey-from-pakistan-beginner-guide-2026.html`  
**Status:** Built and QA-checked; not uploaded to production in this session.

## What changed

- Added a plain-English beginner guide for Pakistani students and parents.
- Added responsive visual explainers for university types, degree levels, academic calendar, language routes, application steps and full-budget categories.
- Added BlogPosting, BreadcrumbList and FAQPage structured data.
- Added a 1200 × 630 branded OG image.
- Updated `blog.html` from 16 to 17 cards and 17 BlogPosting schema records; the new guide is the featured article.
- Updated `sitemap.xml` from 16 to 17 article URLs.
- Fixed two pre-existing live-template defects in the linked IELTS pair:
  - removed the visible `{right_title}` token;
  - restored self-referencing canonical, Open Graph, schema and analytics-slug values in the English and Urdu files.

## Fact corrections applied during source review

The source brief was checked against current official pages on 25 August 2026. The build uses:

- YÖK’s current count of **208 universities**, rather than the broader “200+” wording.
- Current international-admission wording: students apply directly to the university; accepted routes can include TR-YÖS, SAT, IB, Abitur, GCE A Level or school results, according to the university.
- The current YÖK position that state universities no longer run their own international-student exams; old generic “university YÖS” wording was not used.
- Official NQF-HETR duration ranges: associate 2 years, bachelor’s 4 years, master’s 1.5–2 years and doctorate 3–4 years.
- No tuition or total-cost figures, because these are changeable and programme-specific.

## Files to upload

Upload in this order:

1. `images/blog/study-in-turkey-from-pakistan-beginner-guide-2026-og.jpg`
2. `blog/study-in-turkey-from-pakistan-beginner-guide-2026.html`
3. `blog/study-in-turkey-without-ielts-2026.html` — maintenance fix
4. `blog/study-in-turkey-without-ielts-2026-urdu.html` — maintenance fix
5. `blog.html`
6. `sitemap.xml`

## Existing dependency

- `/images/Logo.png` must remain available. The article uses the approved Path Plaza logo already present on production. The release does not require replacing the production logo.
- `PP_GA4_ID` remains blank. Tracking will not load until management supplies and approves an ID.
- The requested release is English only. No Urdu counterpart was invented; the sitemap uses `en-PK` and `x-default` self-alternates for this article.

## Production integration

1. Back up every file that will be replaced.
2. Upload the OG image first, then the article and maintenance files.
3. Upload `blog.html` and `sitemap.xml` last so they never point to a missing article.
4. Purge hosting/CDN page cache for the article, blog index and sitemap.
5. Open the canonical article URL in a private browser window.
6. Confirm the OG image returns HTTP 200 and is 1200 × 630.
7. Confirm the blog index shows 17 cards and the new article is featured.
8. Confirm the sitemap contains 17 article URLs.
9. Confirm both IELTS pages show “A risky route” / “خطرے والا راستہ” and have self canonicals.
10. Run the contact-release crawler again after this publication only if the wider contact fixes have also been deployed.

## Rollback

Restore the backed-up `blog.html`, `sitemap.xml` and two IELTS pages, then remove the new article and OG image. Purge cache again.

## Important operational note

The earlier production contact-release smoke test remains failed for unrelated shell/country-page issues. This blog build does not close that ticket. Human management publication approval and production access are still required.
