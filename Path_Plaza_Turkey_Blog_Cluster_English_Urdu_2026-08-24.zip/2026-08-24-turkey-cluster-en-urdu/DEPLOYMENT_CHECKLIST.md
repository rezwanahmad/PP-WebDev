# Turkey Blog Cluster Release — English + Urdu

**Release date:** 24 August 2026
**Scope:** 16 live article pages (8 topics × English/Urdu)

## Upload order
1. Upload `fonts/NotoNastaliqUrdu-Arabic.woff2`.
2. Upload every `.html` file in `blog/`.
3. Upload root `blog.html`.
4. Upload root `sitemap.xml`.
5. Purge server/CDN caches.
6. Verify every URL in `Turkey_Cluster_Article_Manifest_2026-08-24.csv`.
7. Submit sitemap only after all 16 article URLs return their own titles.

## Acceptance
- Blog index shows 16 cards; Urdu filter shows 8.
- Sitemap contains 16 article URLs and 48 hreflang annotations.
- No template tokens or future dates.
- Displayed contact is `92315-500-9620`; wa.me links remain digits-only.
- English/Urdu switches work both ways.
- FAQ schema matches visible text.
- No article is deployed without blog.html and sitemap.xml from this bundle.
